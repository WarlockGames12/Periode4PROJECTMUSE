using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;

public class MainMenu : MonoBehaviour
{

    public string levelToLoad = "MainLevel";
    public void Play()
    {
        SceneManager.LoadScene("MainLevel");
        Debug.Log("Play");
    }
}
